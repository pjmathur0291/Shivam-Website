			<!-- HERE IS THE STARTING OF THE TOP FOOTER PART -->
				<!-- ---------------------- -->
<div class="container-fluid" id="fluid">
    <div class="container-fluid_overlay">
        <div class="row mx-auto text-left product">
            <div class="col-sm-12 col-md-12 col-lg-3 text-white mt-3 mb-3 border-right-right">
                <span class="indi">
                    CALL US
                </span>
                <span class="indi">
                    Tel: (+91)9057807060 | (+91)8003141049
                </span>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-3 text-white mt-3 mb-3 border-right-right">
                <span class="card-heading">
                    EMAIL IS
                </span>
                <span class="product-content">
                    wingstotalcarsolution@gmail.com
                </span>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-3 text-white mt-3 mb-3 border-right-right" style="border: none;">
                <span class="card-heading">
                    BREAKDOWN SERVICES
                </span>
                <span class="product-content">
                    WE PROVIDE ALL TYPES OF SERVICES WHICH ARE REQUIRED IN BREAKDOWN
                </span>
            </div>
        </div>
    </div>
</div>
			<!-- HERE IS THE ENDING OF THE TOP FOOTER PART -->
				<!-- ---------------------- -->
			<!-- HERE IS THE STARTING OF THE MAIN FOOTER SECTION -->

<div class="container-fluid footer">
	<div class="container">
		<div class="row pt-4 pb-4">
			<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 text-white">
				<div class="footer_header text-capitalize text-justify pl-3 h4 pt-4">
					OVER 5 YEARS <br /> EXPERIENCE
				</div>
				<div class="footer_content text-uppercase text-justify pl-3 pt-3 pb-3">
					SINCE BEING ESTABLISHED IN 2015, WINGS TOTAL CAR SOLUTION HAS BEEN KNOWN FOR AN UNPARALLELED COMMITMENT TO CUSTOMER SATISFACTION. IT’S THIS STANDARD OF EXCELLENCE THAT HAS PROVIDED THE IMPETUS FOR US TO GROW INTO THE BUSINESS WE ARE TODAY. FOR MORE INFORMATION ABOUT THE PRODUCTS AND SERVICES WE PROVIDE, REACH OUT TODAY.
				</div>
			</div>

			<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 text-white">
				<div class="footer_header text-capitalize h4 pl-3 pt-4">
					OUR SERVICES
				</div>
				<div class="footer_content footer_content_other text-left pl-3 text-uppercase pb-3">
					- <a href="services.php">MECHANIC ON SPOT</a><br /><br />

					- <a href="services.php">CRANE SERVICE</a> <br /><br />

					- <a href="services.php">TOWING SERVICES</a> <br /><br />

					- <a href="services.php">MEDICAL ASSISTANCE</a> <br /><br />

					- <a href="services.php">JUMP BATTARY START</a><br /><br />

				</div>
			</div>

			<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 text-white">
				<div class="footer_header text-capitalize h4 pl-3 pt-4">
					VISIT US
				</div>
				<div class="footer_content footer_content_other text-left pl-3 pb-3">
					17E/287 CHOPASNI HOUSING
					BOARD, JODHPUR (RAJ.), 342001<br /><br />

					wingstotalcarsolution@gmail.com<br /><br />

					+91 8003141049 | +91 9057807060<br /><br />
				</div>
			</div>
		</div>
	</div>
</div>

		<!-- HERE IS THE ENDING OF THE MAIN FOOTER PART -->