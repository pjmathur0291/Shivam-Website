<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@515&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Barlow:ital@1&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@100&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
	<link rel="stylesheet" type="text/css" href="css/responsive.css" />
	<title>Service</title>
</head>
<body>

	<!-- HERE IS THE STARTING OF THE HEADER SECTION  -->
	<?php
	include 'header/header.php';
	?>
	<!-- HERE IS THE ENDING OF THE HEADER SECTION  -->

	<!-- -------------- -->


	<div class="container-fluid">
		<div class="container">
			<!-- HERE IS THE STARTING OF THE HEADING SECTION --> 
			<div class="row">
				<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center h1 terms_heading text-uppercase">
					WHAT SERVICES DO WE NEED?
				</div>
			</div>
		</div>
	</div>

	<!-- HERE IS THE ENDING OF THE HEADING SECTION -->


	<!-- HERE IS THE STARTING OF THE HEADING SECTION --> 
	<div class="container-fluid">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-md-12 col-xl-12 col-lg-12 pt-3 pb-3 services_content">
					Services are the set of services which are needed in RSA while driving from one place to another without any type of inconvenience. We provide our members all these services mentioned below. We are going to provide you all types of services which are required in RSA with <b>exciting offers</b> in limited cities.
				</div>
			</div>
		</div>
	</div>
	<!-- HERE IS THE ENDING OF THE HEADING SECTION --> 


	<!-- HERE IS THE STARTING OF THE MAIN SERVICES PROVIDE -->
	<div class="container-fluid">
		<div class="container">
			<div class="row pt-4">

				<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 text-center pt-4 pb-4">
					<img src="images/tool1.jpg" class="text-center" width="100" height="100" /><br />
					<span class="text-right service_heading_index">
						MECHANIC ON SPOT
					</span>
					<p class="text-center pt-5 service_content">
						WE ARE GOING TO PROVIDE MECHANIC ON SPOT, WHENEVER THE
						CAR GET DISTURB OR CAN'T ABLE TO MOVE, CALL US. WE PROVIDE
						YOU THE NEAREST MECHANIC.
					</p>
				</div>

				<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 text-center pt-4 pb-4">
					<img src="images/towing.jpg" class="text-center" width="130" height="100" /><br />
					<span class="text-right service_heading_index">
						TOWING SERVICE
					</span>
					<p class="text-center pt-5 service_content">
						WE ALSO PROVIDE OUR MEMBERS TOWING SERVICE, WHEN OUR
						MECHANIC IS UNABLE TO REPAIR CAR OR DUE TO LACK OF TOOLS
						ON SPOT, HE WILL TOW YOUR CAR TO HIS GARAGE AND MAKE IT FIX.
					</p>
				</div>

				<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 text-center pt-4 pb-4">
					<img src="images/oil.jfif" class="text-center" width="100" height="100" /><br />
					<span class="text-right service_heading_index">
						FUEL REFILL
					</span>
					<p class="text-center pt-5 service_content">
						IF THE MEMBER FORGOT TO FILL THE SUFFICIENT AMOUNT OF FUEL, AND
						THE CAR BREAKSDOWN, THEN OUR MECHANIC REFILL YOUR CAR WITH FUEL
					</p>
				</div>

				<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 text-center pt-4 pb-4">
					<img src="images/tow2.jpg" class="text-center" width="130" height="130" /><br />
					<span class="text-right service_heading_index">
						CRANE SERVICE
					</span>
					<p class="text-center pt-5 service_content">
						WINGS ALSO PROVIDE CRANE SERVICE WHICH HELPS THE MEMBER.
						IN CASE OF ACCIDENTAL CAR, WE ALSO PROVIDE THE MEMBER
						CRANE SERVICE FROM BREAKDOWN SPOT TO HIS DESTINATION
					</p>
				</div>

				<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 text-center pt-4 pb-4">
					<img src="images/medical1.jpg" class="text-center" width="110" height="130" /><br />
					<span class="text-right service_heading_index">
						MEDICAL ASSISTANCE
					</span>
					<p class="text-center pt-5 service_content">
						IN CASE OF ANY ACCIDENTAL CAUSE, THE MEMBER OR ANY OTHER
						FAMILY MEMBER GOT HURT, IN THIS CASE WE TOO PROVIDE MEDICAL
						ASSISTANCE TO THE MEMBER BY CONSULTING TO DOCTOR ON CALL
					</p>
				</div>

				<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 text-center pt-4 pb-4">
					<img src="images/battary.jpg" class="text-center" width="110" height="130" /><br />
					<span class="text-right service_heading_index">
						JUMP BATTERY START
					</span>
					<p class="text-center pt-5 service_content">
						IN CASE THERE IS SONE BATERY ISSUE AND CAR BREAKDOWN
						WE ALSO PROVIDE OUR MEMBER THE JUMP BATTERY START.
					</p>
				</div>

			</div>
		</div>
	</div>
	<!-- HERE IS THE ENDING OF THE MAIN SERVICES PROVIDE -->

	<!-- ------------------------------------------------------- -->

	<!-- HERE IS THE STARTING OF THE STATE COVERED SECTION -->

	<div class="container-fluid container-fluid_state">
		<div class="container pt-4">

			<div class="row">
				<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center pt-4 pb-4 state_cover_heading">
					STATE COVERED FOR RSA
				</div>
			</div>

			<div class="row">
				<div class="col-sm-12 col-md-12 col-lg-8 col-xl-8 mx-auto text-center pb-4 state_covered">
					M.P. | RAJASTHAN | MAHARASHTRA | GOA | GUJRAT | DAMAN & DIU | UTTAR PRADESH | BIHAR | HIMACHAL PRADESH | PUNJAB | DELHI UTTARKHAND | NCR | HARYANA | CHANDIGARH CHHATTISGARH | JHARKHAND
				</div>
			</div>
		</div>
	</div>

	<!-- HERE IS THE ENDING OF THE STATE COVERED SECTION -->

	<!-- ---------------------------------------------------- -->

	<!-- HERE IS TEH STARTING OF THE FOOTER PAGE  -->
	<?php
	include 'footer/footer.php' 
	?>
	<!-- HERE IS THE ENDING OF THE FOOTER PAGE -->

	<!-- -------------- -->

	<!-- HERE IS THE JAVASCRIPT CDN LINKS  -->
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
</body>
</html>