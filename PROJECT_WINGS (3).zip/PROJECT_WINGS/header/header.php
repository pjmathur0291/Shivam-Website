<div class="container-fluid bg-white fixed-top" style="height: auto;">
	<div class="container" id="nav_container">

		<nav class="navbar navbar-expand-md navbar-dark ">
			<header class="container">
				<a class="navbar-brand" href="index.php">
					<img src="images/wings_logo.jpg" width="100" height="100" class="img-fluid" id="logo" />
				</a>
				<button class="navbar-toggler bg-dark ml-4 3x" type="button" data-toggle="collapse" data-target="#wings_navbar" aria-controls="wings_navbar" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="wings_navbar">
					<ul class="navbar-nav ml-auto fade-out" id="wings_nav">
						<li class="nav-item active">
							<a class="nav-link text-dark active" href="index.php">Home</a>
						</li>
						<li class="nav-item pr-2">
							<a class="nav-link text-dark" href="about_us.php">About</a>
						</li>
						<li class="nav-item pr-2">
							<a class="nav-link text-dark" href="services.php">Services</a>
						</li>
						<li class="nav-item pr-2">
							<a class="nav-link text-dark" href="contact.php">Contact Us</a>
						</li>
						<li class="nav-item pr-2">
							<a class="nav-link text-dark" href="terms&condition.php">T&C's</a>
						</li>
					</ul>
				</div>
			</header>
		</nav>
	</div>
</div>