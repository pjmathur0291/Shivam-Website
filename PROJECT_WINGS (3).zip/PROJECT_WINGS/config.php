<?php
	function p($data,$die = 1){
		echo "<pre>";
		print_r($data);
		if($die)
			die;	
	}
	if(isset($_POST['contact_submit_message'])){
	$server = "localhost";
	$username = "root";
	$password = "";
	$db = "project_wings";

	$con = mysqli_connect($server, $username, $password, $db);

	if (!$con) {
		die("CONNECTION UNSUCCESSFUL DUE TO" . mysqli_connect_error());
	}

			// CONTACT US DETAILS

	$customer_name = $_POST['customer_name'];
	$customer_email = $_POST['customer_email'];
	$customer_subject = $_POST['customer_subject'];
	$customer_number = $_POST['customer_number'];
	$customer_message = $_POST['customer_message'];



	// $sql = "INSERT INTO `wings_customer_message`(customer_name, customer_email, customer_subject, customer_number, customer_message) VALUES ("$customer_name","$customer_name","$customer_email","$customer_subject","$customer_number","$customer_message")";


	$sql = "INSERT INTO `wings_customer_message` (`customer_name`, `customer_email`, `customer_subject`, `customer_number`, `customer_message`) VALUES ('$customer_name', '$customer_email', '$customer_subject', '$customer_number', '$customer_message')";
	
	mysqli_query($con, $sql);
	// p(mysqli_error_list($con));
}
	
?>