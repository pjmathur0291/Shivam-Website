<?php
    include 'config.php';
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@515&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Barlow:ital@1&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@100&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
	<link rel="stylesheet" type="text/css" href="css/responsive.css" />

	<title>Contact Us</title>
</head>
<body>
	<!-- HERE IS THE STARTING OF THE HEADER PART -->
	
	<!-- HERE IS THE ENDING OF THE HEADER PART -->
	<?php
           include 'header/header.php';
        ?>

	<div class="container-fluid">
		<div class="container">
			<!-- HERE IS THE STARTING OF THE HEADING SECTION --> 
			<div class="row">
				<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center h1 terms_heading text-uppercase">
					CONTACT US TODAY!
				</div>
			</div>
		</div>
	</div>


	<div class="container-fluid">
		<div class="container mt-4">
			<div class="row">

				<div class="col-sm-12 col-md-12 text-center col-lg-6 col-xl-6">
					<span class="contact_info_heading">
						Telephone
					</span><br />	
					<span class="contact_info_content">
						Tel: 800-314-1049 | 905-780-7060
					</span><br /> <br />

					<span class="contact_info_heading">
						Email
					</span><br />	
					<span class="contact_info_content">
						wingstotalcarsolution@gmail.com
					</span><br /> <br />

					<span class="contact_info_heading">
						Opening Hours
					</span><br />	
					<span class="contact_info_content">
						Mon - Fri: 7am - 10pm <br />
						Saturday: 8am - 10pm
					</span><br /> <br />
				</div>

				<div class="col-sm-12 col-md-12 col-lg-6 col-xl-6">
					<!-- HERE IS THE STARTING OF THE FORM SECTION -->

					<div class="col-sm-12 col-md-12 h3 mobile_switch text-capitalize">
						Drop us a message
					</div>

					<form method="post" action="">
						<div class="form-group">
							<input type="text" value="" class="form-control" name="customer_name" id="exampleFormControlInput1" placeholder="Name">
						</div>
						<div class="form-group">
							<input type="email" value="" class="form-control" name="customer_email" id="exampleFormControlInput1" placeholder="Email">
						</div>
						<div class="form-group">
							<input type="text" value="" value="" class="form-control" name="customer_subject" id="exampleFormControlInput1" placeholder="Subject">
						</div>
						<div class="form-group">
							<input type="number" value="" class="form-control" name="customer_number" id="exampleFormControlInput1" placeholder="Phone Number">
						</div>
						<div class="form-group">
							<textarea class="form-control" value="" name="customer_message" placeholder="Message" id="exampleFormControlTextarea1" rows="3"></textarea>
						</div>
						<button type="submit" name="contact_submit_message" value="Get in Touch" class="btn btn-primary mb-2">Get in Touch</button>
					</form>
					<!-- HERE IS THE ENDING OF THE FORM SECTION -->
				</div>
			</div>
		</div>
	</div>



	<!-- HERE IS THE STARTING OF THE MAP SECTION IN CONTACT US SECTION -->

	<div class="container-fluid container-fluid_map_contact">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-md-12 col-lg-6 col-xl-12 mt-3 contact_us_map_top text-center">
					GETTING HERE:
				</div>
				<div class="col-sm-12 col-md-12 col-lg-6 col-xl-12 mb-3 contact_us_map_top text-center">
					17e/287, Chopasni Housing Board Jodhpur (Raj.), 342001
				</div>
				<div class="col-sm-12 col-md-12 col-lg-6 col-xl-12 mb-4 contact_us_map_top text-center">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3578.0196676259084!2d72.96152325057527!3d26.261025083331198!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39418f617c379291%3A0x274c5fb43a28e4c1!2sWings%20total%20car%20solution!5e0!3m2!1sen!2sin!4v1624433984093!5m2!1sen!2sin" class="mb-4" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
				</div>
			</div>
		</div>
	</div>

	<!-- HERE IS THE ENDING OF THE MAP SECTION IN CONTACT US SECTION -->

	<!-- HERE IS TEH STARTING OF THE FOOTER PAGE  -->
        <?php
            include 'footer/footer.php';
        ?>
    <!-- HERE IS THE ENDING OF THE FOOTER PAGE -->

        <!-- -------------- -->


	<!-- HERE IS THE JAVASCRIPT CDN LINKS  -->
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
</body>
</html>